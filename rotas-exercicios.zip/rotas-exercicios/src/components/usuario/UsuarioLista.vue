<template>
    <div class="usuario-lista">
        <h3>Lista de Usuários</h3>
        <ul class="lista">
            <router-link tag="li" to="/usuario/1"
                class="item-lista">Usuário 1</router-link>
            <router-link tag="li" to="/usuario/2"
                class="item-lista">Usuário 2</router-link>
            <router-link tag="li" to="/usuario/3"
                class="item-lista">Usuário 3</router-link>
        </ul>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
