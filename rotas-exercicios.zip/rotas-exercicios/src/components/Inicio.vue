<template>
    <div class="inicio">
        <h2>Início</h2>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
